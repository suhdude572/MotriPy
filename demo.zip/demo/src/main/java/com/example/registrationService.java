package com.example;

import io.vertx.core.Handler;
import io.vertx.core.http.HttpHeaders;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.UUID;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;


public class registrationService implements Handler<RoutingContext> {

    public void handle(RoutingContext routingContext) {
        String email = routingContext.request().getParam("email");
        String password = routingContext.request().getParam("password");

        if (email == null || email.isEmpty() || !email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            JsonObject errorResponse = new JsonObject().put("error", "El campo de correo electrónico no es válido");
            routingContext.response().putHeader(HttpHeaders.CONTENT_TYPE, "application/json").setStatusCode(400).end(Json.encodePrettily(errorResponse));
            return;
        }

        if (password == null || password.isEmpty() || password.length() < 8) {
            JsonObject errorResponse = new JsonObject().put("error", "El campo de contraseña debe tener al menos 8 caracteres");
            routingContext.response().putHeader(HttpHeaders.CONTENT_TYPE, "application/json").setStatusCode(400).end(Json.encodePrettily(errorResponse));
            return;
        }
        
        try (dbConnection dbConn = new dbConnection("jdbc:mysql://localhost:3306/mydatabase", "myuser", "mypassword")) {
             Connection conn = dbConn.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM users WHERE email = ?");
            stmt.setString(1, email);
            if (stmt.executeQuery().next()) {
                int count = stmt.getResultSet().getInt(1);
                if (count > 0) {
                    JsonObject errorResponse = new JsonObject().put("error", "El correo electrónico ya está registrado");
                    routingContext.response().putHeader(HttpHeaders.CONTENT_TYPE, "application/json").setStatusCode(400).end(Json.encodePrettily(errorResponse));
                    return;
                }
            }
            String confirmationKey = generateConfirmationKey();
            stmt = conn.prepareStatement("INSERT INTO users (email, password, confirmation_key) VALUES (?, ?, ?)");
            stmt.setString(1, email);
            stmt.setString(2, password);
            stmt.setString(3, confirmationKey);
            stmt.executeUpdate();
            sendConfirmationEmail(email, confirmationKey);
            JsonObject successResponse = new JsonObject().put("message", "El registro ha sido exitoso. Por favor, revise su correo electrónico para confirmar su cuenta.");
            routingContext.response().putHeader(HttpHeaders.CONTENT_TYPE, "application/json").setStatusCode(200).end(Json.encodePrettily(successResponse));
        } catch (SQLException e) {
            routingContext.fail(e);
        }
    }

    private String generateConfirmationKey() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    private void sendConfirmationEmail(String email, String confirmationKey) {
        // Configurar las propiedades del servidor de correo electrónico
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com"); // Cambiar al host del servidor SMTP correspondiente
        properties.put("mail.smtp.port", "587"); // Cambiar al puerto correspondiente
        
        // Crear una sesión de correo electrónico con autenticación
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("motripyprueba@gmail.com", "000prueba!"); // Cambiar al correo y contraseña de la cuenta que enviará el correo electrónico
            }
        });
        
        try {
            // Crear el mensaje de correo electrónico
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("tu_correo_electronico@gmail.com")); // Cambiar al correo de la cuenta que enviará el correo electrónico
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));
            message.setSubject("Confirmación de registro");
            message.setText("Por favor confirma tu cuenta haciendo clic en el siguiente enlace: "
                + "https://bechir96.github.io/MotriPy/confirmar?clave=" + confirmationKey);
            
            // Enviar el mensaje de correo electrónico
            Transport.send(message);
            
            System.out.println("El correo electrónico de confirmación ha sido enviado a " + email);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}

