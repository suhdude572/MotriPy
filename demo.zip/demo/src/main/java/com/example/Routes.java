package com.example;

import java.io.IOException;
import java.io.OutputStream;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

public class Routes {
    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create();
        server.createContext("/register", new RegistrationService());
        server.setExecutor(null);
        server.start();
    }
}

class RegistrationService implements HttpHandler {
    public void handle(HttpExchange exchange) throws IOException {
        String response = "This is the registration page";
        exchange.sendResponseHeaders(200, response.length());
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
}